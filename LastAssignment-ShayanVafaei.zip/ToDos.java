
// Shayan Vafaei
// 99222115

import java.util.ArrayList;

public class ToDos {
    public static void main(String[] args) {
        // Sherlock Holmes
        ArrayList<String> sherlocksToDos = new ArrayList<>();
        sherlocksToDos.add("visit the crime scene");
        sherlocksToDos.add("play violin");
        sherlocksToDos.add("interview suspects");
        sherlocksToDos.add("solve the case");
        sherlocksToDos.add("apprehend the criminal");

        // Hercules Poirot
        ArrayList<String> poirotsToDos = new ArrayList<>();
        poirotsToDos.add("visit the crime scene");
        poirotsToDos.add("interview suspects");
        poirotsToDos.add("let the little grey cells do their work");
        poirotsToDos.add("trim mustache");
        poirotsToDos.add("call all suspects together");
        poirotsToDos.add("reveal the truth of the crime");

        // Size of each ArrayList
        System.out.println("Sherlock has " + sherlocksToDos.size() + " things to do.");
        System.out.println("Poirot has " + poirotsToDos.size() + " things to do.");

        // Detective with the larger to-do list
        if (sherlocksToDos.size() < poirotsToDos.size()) {
            System.out.println("Poirot has more things to do.");
        } else {
            System.out.println("Sherlock has more things to do.");
        }
    }
}