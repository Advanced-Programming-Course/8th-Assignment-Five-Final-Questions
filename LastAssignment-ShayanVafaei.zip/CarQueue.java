
// Shayan Vafaei
// 99222115

import java.util.LinkedList;
import java.util.Queue;

class Car {
    private String make;
    private String model;

    public Car(String make, String model) {
        this.make = make;
        this.model = model;
    }

    @Override
    public String toString() {
        return make + " " + model;
    }
}

public class CarQueue {
    public static void main(String[] args) {
        // Create a queue of cars
        Queue<Car> carQueue = new LinkedList<>();

        // Add cars to the queue
        carQueue.offer(new Car("Toyota", "Camry"));
        carQueue.offer(new Car("Honda", "Civic"));
        carQueue.offer(new Car("Ford", "Mustang"));
        carQueue.offer(new Car("Chevrolet", "Corvette"));
        carQueue.offer(new Car("BMW", "X5"));

        // Print the contents of the queue
        System.out.println("Cars in the queue:");
        for (Car car : carQueue) {
            System.out.println(car);
        }

        // Dequeue the cars
        System.out.println("\nDequeuing cars:");
        while (!carQueue.isEmpty()) {
            Car car = carQueue.poll();
            System.out.println("Dequeued: " + car);
        }

        // Check if the queue is empty
        if (carQueue.isEmpty()) {
            System.out.println("\nThe queue is empty.");
        } else {
            System.out.println("\nThe queue is not empty.");
        }
    }
}