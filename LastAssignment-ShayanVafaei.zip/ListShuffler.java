
// Shayan Vafaei
// 99222115

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class ListShuffler {
    public static void main(String[] args) {
        // LinkedList
        List<String> members = new LinkedList<>();
        members.add("Ali");
        members.add("Reza");
        members.add("Hasan");
        members.add("Sina");
        members.add("Pouya");

        System.out.println("Original List:");
        printList(members);

        // Shuffle
        shuffleList(members);

        System.out.println("\nShuffled List:");
        printList(members);
    }

    public static void shuffleList(List<String> list) {

        Random random = new Random();

        for (int i = list.size() - 1; i > 0; i--) {
            int randomIndex = random.nextInt(i + 1);
            Collections.swap(list, i, randomIndex);
        }
    }

    public static void printList(List<String> list) {
        for (String member : list) {
            System.out.println(member);
        }
    }
}