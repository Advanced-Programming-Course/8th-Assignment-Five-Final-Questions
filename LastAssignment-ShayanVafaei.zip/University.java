
// Shayan Vafaei
// 99222115

import java.util.Scanner;
import java.util.TreeSet;

class Student implements Comparable<Student> {
    private String name;
    private int studentNumber;
    private double gpa;

    public Student(String name, int studentNumber, double gpa) {
        this.name = name;
        this.studentNumber = studentNumber;
        this.gpa = gpa;
    }

    public int getStudentNumber() {
        return studentNumber;
    }

    @Override
    public int compareTo(Student other) {
        return Integer.compare(this.studentNumber, other.studentNumber);
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Student Number: " + studentNumber + ", GPA: " + gpa;
    }
}

public class University {
    public static void main(String[] args) {
        TreeSet<Student> students = new TreeSet<>();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter student details (name, student number, GPA):");

        while (true) {
            System.out.print("Name (or 'q' to quit): ");
            String name = scanner.nextLine();
            if (name.equalsIgnoreCase("q")) {
                break;
            } else if (name.equalsIgnoreCase("r")) {
                registerNewStudent(students, scanner);
                continue;
            }

            System.out.print("Student Number: ");
            int studentNumber = scanner.nextInt();
            scanner.nextLine();

            System.out.print("GPA: ");
            double gpa = scanner.nextDouble();
            scanner.nextLine(); 

            Student student = new Student(name, studentNumber, gpa);
            students.add(student);
        }

        System.out.println("\nStudent List:");
        for (Student student : students) {
            System.out.println(student);
        }

        while (true) {
            System.out.print("\nEnter student number to search(enter 'r' to register new student): ");
            String input = scanner.nextLine();
            if (input.equalsIgnoreCase("r")) {
                registerNewStudent(students, scanner);
            } else {
                try {
                    int searchNumber = Integer.parseInt(input);
                    Student searchedStudent = new Student("", searchNumber, 0.0);
                    if (students.contains(searchedStudent)) {
                        System.out.println("\nStudent Profile:");
                        System.out.println(students.ceiling(searchedStudent));
                        break;
                    } else {
                        System.out.println("\nStudent not found.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("\nInvalid input.");
                }
            }
        }
    }

    private static void registerNewStudent(TreeSet<Student> students, Scanner scanner) {
        System.out.print("Name: ");
        String name = scanner.nextLine();

        System.out.print("Student Number: ");
        int studentNumber = scanner.nextInt();
        scanner.nextLine(); // consume newline character

        System.out.print("GPA: ");
        double gpa = scanner.nextDouble();
        scanner.nextLine(); // consume newline character

        Student student = new Student(name, studentNumber, gpa);
        students.add(student);
        System.out.println("Student registered successfully.");
    }
}