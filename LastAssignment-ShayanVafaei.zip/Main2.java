import java.util.*;
import java.util.stream.Collectors;

class OnlineShop {
    private String name;
    private String webAddress;
    private String supportNumber;
    private List<User> users;
    private List<Product> products;
    private List<Order> orders;
    private double totalProfit;

    public OnlineShop(String name, String webAddress, String supportNumber) {
        this.name = name;
        this.webAddress = webAddress;
        this.supportNumber = supportNumber;
        this.users = new ArrayList<>();
        this.products = new ArrayList<>();
        this.orders = new ArrayList<>();
        this.totalProfit = 0;
    }

    // Method to register a user
    public void registerUser(User user) {
        users.add(user);
        System.out.println("User registered successfully.");
    }

    // Method to login a user
    public User loginUser(String username, String password) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                System.out.println("Login successful.");
                return user;
            }
        }
        System.out.println("Invalid username or password.");
        return null;
    }

    // Method to add product
    public void addProduct(Product product) {
        products.add(product);
        System.out.println("Product added successfully.");
    }

    // Method to list products
    public void listProducts() {
        for (Product product : products) {
            System.out.println(product);
        }
    }

    // Method to add an order
    public void addOrder(Order order) {
        orders.add(order);
        System.out.println("Order placed successfully.");
    }

    // Method to approve an order
    public void approveOrder(Order order) {
        if (order.isApproved()) {
            System.out.println("Order is already approved.");
        } else {
            order.setApproved(true);
            totalProfit += order.getTotalCost() * 0.1;
            System.out.println("Order approved successfully.");
        }
    }

    public void viewTotalProfit() {
        System.out.println("Total profit: $" + totalProfit);
    }
}

// User classes
abstract class User {
    protected String username;
    protected String password;
    protected String email;
    protected String phoneNumber;
    protected String address;
    protected ShoppingCart cart;
    protected List<Order> orders;
    protected List<Product> purchasedProducts;
    protected double wallet;

    public User(String username, String password, String email, String phoneNumber, String address) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.cart = new ShoppingCart();
        this.orders = new ArrayList<>();
        this.purchasedProducts = new ArrayList<>();
        this.wallet = 0;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    // Methods for adding funds to wallet
    public void addFunds(double amount) {
        wallet += amount;
        System.out.println("Funds added successfully.");
    }

    // Methods to view profile
    public void viewProfile() {
        System.out.println("Username: " + username);
        System.out.println("Email: " + email);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Address: " + address);
    }

    // Methods for cart management
    public void addToCart(Product product, int quantity) {
        cart.addProduct(product, quantity);
        System.out.println("Product added to cart.");
    }

    public void viewCart() {
        cart.viewCart();
    }

    // Method to place an order
    public void placeOrder(OnlineShop shop) {
        Order order = new Order(this, new ArrayList<>(cart.getProducts().values()));
        if (wallet >= order.getTotalCost()) {
            orders.add(order);
            shop.addOrder(order);
            wallet -= order.getTotalCost();
            System.out.println("Order placed successfully.");
        } else {
            System.out.println("Insufficient funds to place the order.");
        }
    }
}

class Admin extends User {
    public Admin(String username, String password, String email) {
        super(username, password, email, "", "");
    }

    // Method to approve a seller
    public void approveSeller(Seller seller) {
        seller.setApproved(true);
        System.out.println("Seller approved successfully.");
    }
}

class Seller extends User {
    private String companyName;
    private List<Product> availableProducts;
    private boolean isApproved;

    public Seller(String companyName, String username, String password, String email, String phoneNumber, String address) {
        super(username, password, email, phoneNumber, address);
        this.companyName = companyName;
        this.availableProducts = new ArrayList<>();
        this.isApproved = false;
    }

    public void setApproved(boolean isApproved) {
        this.isApproved = isApproved;
    }

    // Method to add product
    public void addProduct(Product product, OnlineShop shop) {
        if (isApproved) {
            availableProducts.add(product);
            shop.addProduct(product);
            System.out.println("Product added to shop successfully.");
        } else {
            System.out.println("Seller is not approved to add products.");
        }
    }
}

class Customer extends User {
    public Customer(String username, String password, String email, String phoneNumber, String address) {
        super(username, password, email, phoneNumber, address);
    }

    // Additional customer-specific methods can be added here
}

// Product classes
abstract class Product {
    protected String name;
    protected double price;
    protected int inventory;
    protected List<Review> reviews;

    public Product(String name, double price, int inventory) {
        this.name = name;
        this.price = price;
        this.inventory = inventory;
        this.reviews = new ArrayList<>();
    }

    public double getPrice() {
        return price;
    }

    public int getInventory() {
        return inventory;
    }

    public void addReview(Review review) {
        reviews.add(review);
    }

    @Override
    public String toString() {
        return name + " - $" + price + " - " + inventory + " in stock";
    }
}

class Electronics extends Product {
    public Electronics(String name, double price, int inventory) {
        super(name, price, inventory);
    }
}

class Clothing extends Product {
    public Clothing(String name, double price, int inventory) {
        super(name, price, inventory);
    }
}

// Define other product categories similarly

// ShoppingCart class
class ShoppingCart {
    private Map<Product, Integer> products;

    public ShoppingCart() {
        this.products = new HashMap<>();
    }

    public void addProduct(Product product, int quantity) {
        if (product.getInventory() >= quantity) {
            products.put(product, quantity);
        } else {
            System.out.println("Insufficient inventory for " + product);
        }
    }

    public void viewCart() {
        for (Map.Entry<Product, Integer> entry : products.entrySet()) {
            System.out.println(entry.getKey() + " - Quantity: " + entry.getValue());
        }
    }

    public Map<Product, Integer> getProducts() {
        return products;
    }
}

// Order class
class Order {
    private User user;
    private List<Product> products;
    private double totalCost;
    private boolean isApproved;

    public Order(User user, List<Product> products) {
        this.user = user;
        this.products = products;
        this.totalCost = products.stream().mapToDouble(Product::getPrice).sum();
        this.isApproved = false;
    }

    public double getTotalCost() {
        return totalCost;
    }

    public boolean isApproved() {
        return isApproved;
    }

    public void setApproved(boolean approved) {
        isApproved = approved;
    }

    @Override
    public String toString() {
        return "Order{" +
                "user=" + user.getUsername() +
                ", totalCost=" + totalCost +
                ", isApproved=" + isApproved +
                '}';
    }
}

// Review class
class Review {
    private String reviewer;
    private String comment;
    private int rating;

    public Review(String reviewer, String comment, int rating) {
        this.reviewer = reviewer;
        this.comment = comment;
        this.rating = rating;
    }

    @Override
    public String toString() {
        return "Review{" +
                "reviewer='" + reviewer + '\'' +
                ", comment='" + comment + '\'' +
                ", rating=" + rating +
                '}';
    }
}

// Main class to run the application
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        OnlineShop shop = new OnlineShop("My Shop", "www.myshop.com", "123-456-7890");

        // Initial predefined admin
        Admin admin = new Admin("admin", "password", "admin@myshop.com");
        shop.registerUser(admin);

        while (true) {
            System.out.println("1. Register\n2. Login\n3. Exit");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.println("Register as:\n1. Customer\n2. Seller");
                    int type = scanner.nextInt();
                    scanner.nextLine(); // consume newline

                    System.out.print("Enter username: ");
                    String username = scanner.nextLine();
                    System.out.print("Enter password: ");
                    String password = scanner.nextLine();
                    System.out.print("Enter email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter phone number: ");
                    String phoneNumber = scanner.nextLine();
                    System.out.print("Enter address: ");
                    String address = scanner.nextLine();

                    if (type == 1) {
                        Customer customer = new Customer(username, password, email, phoneNumber, address);
                        shop.registerUser(customer);
                    } else if (type == 2) {
                        System.out.print("Enter company name: ");
                        String companyName = scanner.nextLine();
                        Seller seller = new Seller(companyName, username, password, email, phoneNumber, address);
                        shop.registerUser(seller);
                    }
                    break;

                case 2:
                    System.out.print("Enter username: ");
                    username = scanner.nextLine();
                    System.out.print("Enter password: ");
                    password = scanner.nextLine();

                    User user = shop.loginUser(username, password);
                    if (user != null) {
                        boolean loggedIn = true;
                        while (loggedIn) {
                            System.out.println("1. View Profile\n2. View Cart\n3. Add Funds\n4. Place Order\n5. Logout");
                            int userChoice = scanner.nextInt();
                            scanner.nextLine(); // consume newline

                            switch (userChoice) {
                                case 1:
                                    user.viewProfile();
                                    break;
                                case 2:
                                    user.viewCart();
                                    break;
                                case 3:
                                    System.out.print("Enter amount to add: ");
                                    double amount = scanner.nextDouble();
                                    user.addFunds(amount);
                                    break;
                                case 4:
                                    user.placeOrder(shop);
                                    break;
                                case 5:
                                    loggedIn = false;
                                    break;
                                default:
                                    System.out.println("Invalid choice. Try again.");
                            }
                        }
                    }
                    break;

                case 3:
                    System.out.println("Exiting...");
                    return;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
