import java.util.LinkedList;
import java.util.Queue;

public class CarQueueExample {
    public static void main(String[] args) {

        Queue<String> carQueue = new LinkedList<>();


        carQueue.add("Toyota");
        carQueue.add("Honda");
        carQueue.add("BMW");
        carQueue.add("Ford");


        System.out.println("Contents of the queue: " + carQueue);


        System.out.println("Removing cars from the queue:");
        while (!carQueue.isEmpty()) {
            String removedCar = carQueue.remove();
            System.out.println("Removed: " + removedCar);
        }


        if (carQueue.isEmpty()) {
            System.out.println("Queue is empty now.");
        } else {
            System.out.println("Queue is not empty.");
        }
    }
}
