import java.util.*;

class Student implements Comparable<Student> {
    private String name;
    private int studentId;
    private double gpa;

    public Student(String name, int studentId, double gpa) {
        this.name = name;
        this.studentId = studentId;
        this.gpa = gpa;
    }

    public String getName() {
        return name;
    }

    public int getStudentId() {
        return studentId;
    }

    public double getGpa() {
        return gpa;
    }

    @Override
    public int compareTo(Student other) {
        return Integer.compare(this.studentId, other.studentId);
    }


    @Override
    public String toString() {
        return "Name: " + name + ", Student ID: " + studentId + ", GPA: " + gpa;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TreeSet<Student> students = new TreeSet<>();


        System.out.println("Enter student details or enter 'done' to finish:");
        while (true) {
            System.out.print("Name: ");
            String name = scanner.nextLine();
            if (name.equals("done")) break;

            System.out.print("Student ID: ");
            int studentId = scanner.nextInt();
            scanner.nextLine();

            System.out.print("GPA: ");
            double gpa = scanner.nextDouble();
            scanner.nextLine();

            Student student = new Student(name, studentId, gpa);
            students.add(student);

            System.out.println("Student added.");
        }


        System.out.print("\nEnter student ID to search (or 0 to exit): ");
        int searchId = scanner.nextInt();
        while (searchId != 0) {
            Student searchKey = new Student("", searchId, 0);
            Student foundStudent = students.ceiling(searchKey);
            if (foundStudent != null && foundStudent.getStudentId() == searchId) {
                System.out.println("Student found:");
                System.out.println(foundStudent);
            } else {
                System.out.println("Student with ID " + searchId + " not found.");
            }

            System.out.print("\nEnter student ID to search (or 0 to exit): ");
            searchId = scanner.nextInt();
        }

        System.out.println("Program exited.");
        scanner.close();
    }
}
